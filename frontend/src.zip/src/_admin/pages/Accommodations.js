import React from "react";

export default function Accommodations() {
    return <div>Accommodations</div>;
}
